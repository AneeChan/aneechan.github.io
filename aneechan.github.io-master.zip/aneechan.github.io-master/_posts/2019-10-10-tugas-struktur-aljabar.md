---
layout: post
category: math
tagline: By Mimin
tags:
  - struktur aljabar
  - grup
  - operasi biner
published: true
---
{% include JB/setup %}
Jumpa lagi dengan mimin yang baik hati dan tidak sombong :P kali ini kita akan membahas tugas struktur aljabar. Pembahasan kali ini cukup simpel, dibanding hasil pekerjaan yang mimin tulis di folio. Berikut pembahasan tugas struktur aljabar untuk nomor 1 dan 3. Mimin sengaja buat dalam bentuk dokumen karena males ngetiknya :v dan untuk eksperimen.
<br/>
<a href="https://aneechan.github.io/pdfjs/web/viewer.html?file=solution-for-abstract-algebra-homework.pdf" class="btn btn-danger">Baca Online<span class="glyphicon glyphicon-eye-open" style="margin-left: 5px;"></span></a>
<br/>
Kalo bingung silahkan lambaikan tangan. ^_^
